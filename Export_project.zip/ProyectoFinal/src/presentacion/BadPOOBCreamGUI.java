package presentacion;

public class BadPOOBCreamGUI{
    public static void main(String[] args) {
        new VentanaPrincipal();
    }
}
